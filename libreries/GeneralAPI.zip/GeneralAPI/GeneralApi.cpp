#include "GeneralApi.h"

GeneralApi::GeneralApi(Client &client, char const* api_host, char const* api_url, int api_port, int client_timeout)	{
	this->client = &client;
	this->api_host = api_host;
	this->api_url = api_url;
	this->api_port = api_port;
	this->client_timeout = client_timeout;
}

String GeneralApi::sendGet() {
	String headers="";
	String body="";
	bool finishedHeaders = false;
	bool currentLineIsBlank = true;
	unsigned long now;
	bool avail;
	if (client->connect(api_host, api_port)) {
		if(_debug) { Serial.println(".... connected to server"); }
		String a="";
		char c;
		int ch_count=0;
		client->println("GET " + String(api_url) + " HTTP/1.1");
		client->print("HOST: ");
		client->println(api_host);
		client->println();
		now=millis();
		avail=false;
		while (millis() - now < client_timeout) {
			while (client->available()) {
				avail = finishedHeaders;
				char c = client->read();

				if(!finishedHeaders){
					if (currentLineIsBlank && c == '\n') {
						finishedHeaders = true;
					}
					else{
						headers = headers + c;

					}
				} else {
					if (ch_count < maxMessageLength)  {
						body=body+c;
						ch_count++;
					}
				}

				if (c == '\n') {
					currentLineIsBlank = true;
				}else if (c != '\r') {
					currentLineIsBlank = false;
				}
			}
			if (avail) {
				if(_debug) {
					Serial.println("Body:");
					Serial.println(body);
					Serial.println("END");
				}
				break;
			}
		}
	}
	closeClient();
	return body;
}

bool GeneralApi::get(){
	if(_debug) { Serial.println(F("Closing client")); }
	String response = sendGet();
	DynamicJsonBuffer jsonBuffer;
	JsonObject& root = jsonBuffer.parseObject(response);


	Serial.println(response);


	if(root.success()) {
		if (root.containsKey("data")) {
			
			long data = root["data"];

			info.data = data;

			return true;
		}
	}

	return false;
}

void GeneralApi::closeClient() {
	if(client->connected()) {
		if(_debug) { Serial.println(F("Closing client")); }
		client->stop();
	}
}
