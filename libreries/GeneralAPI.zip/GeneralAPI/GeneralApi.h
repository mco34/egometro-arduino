#ifndef GeneralApi_h
#define GeneralApi_h

#include <Arduino.h>
#include <ArduinoJson.h>
#include <Client.h>




struct information{
  long data;
};

class GeneralApi
{
  public:
    GeneralApi (Client &client, char const*api_host, char const* api_url, int api_port, int client_timeout);
    String sendGet();
    bool get();
    information info;
    bool _debug = true;

  private:
    Client *client;
    char const* api_host;
    char const* api_url;
    int api_port;
    int client_timeout;
    const int maxMessageLength = 1000;
    bool checkForOkResponse(String response);
    void closeClient();
};

#endif
